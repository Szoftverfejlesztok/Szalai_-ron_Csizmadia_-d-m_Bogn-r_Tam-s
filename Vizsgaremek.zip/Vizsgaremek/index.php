<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Kollégiumsegéd</title>
</head>
<body>

    <div class="mainLogin">
    <h1>Kollégiumsegítő program</h1>
    <form action="" method="POST">
        <fieldset>
            <legend><h2>Bejelentkezés</h2></legend>
            
            <input type="text" name="username" placeholder="Felhasználónév">
            <input type="Password" name="password" placeholder="Jelszó">
            <input type="submit" name="login" id="login" value="Bejelentkezés">
        </fieldset>
    </form>
    </div>

    <?php
    $servername = "mysql.omega:3306";
    $db_username = "kollegiumseged";
    $db_password = "KollegiumSeged2025!";
    $dbname = "kollegiumseged";
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    if ($conn->connect_error) {
        die("Kapcsolódási hiba: " . $conn->connect_error);
    }

    if(isset($_POST['login']))
    {
        $username = htmlspecialchars($_POST['username']);
        $password = $_POST['password'];
        $sqlCmd = "SELECT * FROM users WHERE username='$username' and password = '$password'";
        $result = $conn->query($sqlCmd);
        if ($result->num_rows > 0)
        {
            echo "<script>alert('Sikeres bejelentkezés!')</script>";
            session_start();
            while ($row = $result->fetch_assoc())
            {
                $_SESSION['userId'] = htmlspecialchars($row["id"]);
                $_SESSION['accountType'] = htmlspecialchars($row["fiokTipus"]);
                $_SESSION['szakkor'] = htmlspecialchars($row["szakkor"]);
            }
            echo "<script>alert('Sikeres bejelentkezés!')</script>";
            
            if($_SESSION['accountType'] === '1')
            {
                header("Location: admin.php");
            }
            else
            {
                header("Location: control.php");
            }
            
        }else
        {
            echo "<script>alert('A megadott felhasználónév jelszó párosítás nem létezik!')</script>";
        }

    }
    ?>
</body>
</html>