<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--tartalmaza a menü ikont -->    
    <link rel="stylesheet" href="control.css">
    <link rel="stylesheet" href="csoportFNyomtat.css">
    <style>
        .megjelenit
        {
            visibility: hidden;
        }
        .fekete
        {
            color:black;
            visibility: hidden;
        }
        #alair
        {
            border:0px solid black;
        }
        td
            {
                border:1px solid black;
                color:black;
            }
        table
        {
            width: 80%;
            margin-left: auto;
            margin-right:auto;
        }
        @media print {
            .fekete
            {
                visibility: visible;
            }
            .megjelenit
        {
            visibility: visible;
        }
            .eltuntet
            {
                display: none;
            }
        table
            {
                visibility: visible;
            }
        }
    </style>
    <title>Kezelés</title>
</head>
<body>
<?php
    session_start();
    if($_SESSION['accountType'] === null)
    {
        header("Location: logout.php");
    }
    ?>

<?php   
    $servername = "mysql.omega:3306";
    $db_username = "kollegiumseged";
    $db_password = "KollegiumSeged2025!";
    $dbname = "kollegiumseged";
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    if ($conn->connect_error) {
        die("Kapcsolódási hiba: " . $conn->connect_error);
    }
    ?>

        <h1 class="eltuntet">Nevelői felület</h1>
        <button name="hambimenu" class="hambimenu eltuntet" onclick="myFunction()"><i class="fa fa-bars"> Menu</i></button>
        <div id="menu">
            <form method = "GET">
                    <hr>
                    <input type="submit" name="csoportFNaploz" id = "csoportFNaploz" value="Csoportfoglalkozás naplózása">
                    <input type="submit" name="nyomtat" id = "nyomtat" value="Nyomtatás">
                    <input type="submit" name="szakkorNaploz" id = "szakkorNaploz" value="Szakkör naplózása">
                    <br>
                    <input type="submit" name="kijelentkez" id = "kijelentkez" value="Kijelentkezés">
                    <hr>
            </form>
        </div>
        <script>
        function myFunction() {
            var x = document.getElementById("menu");
            if(x.style.display === "block")
            {
                x.style.display = "none";
            }
            else
            {
                x.style.display = "block";
            }
        }
        </script>
    <?php
    if(isset($_GET['kijelentkez']))
    {
        header("Location: logout.php");
    }
    if(isset($_GET['nyomtat']))
    {
        echo "<div class='mainNyomtat'>";
        echo "<h2  style='display: none'class='eltuntet'>Nyomtatás</h2>";
        echo "<form method='POST'>";
        echo "<label class='eltuntet' for=\"datum\">Kérem válassza ki mit szeretne nyomtatni:</label>";
        echo "<br>";
        echo '<select class="eltuntet" name="nyomtat" id="nyomtat">';
        echo '<option value="csoportfoglalkozasnaploz" id="csoportfoglalkozas">Csoportfoglalkozás</option>';
        echo '<option value="szakkorNaploz" id="szakkor">Szakkör</option>';
        echo "</select>";
        echo "<br>";
        echo "<label class='eltuntet' for=\"datum\">Kérem válassza ki a nyomtatni kívánt dátumot:</label>";
        echo "<br>";
        $datetime = new DateTime("now", new DateTImeZone("Europe/Belgrade"));
        $jelenlegiIdo = $datetime->format('Y-m-d');
        echo "<input class='eltuntet' id='datum' name='datum' value='$jelenlegiIdo' type=\"date\">";
        echo "<br>";
        echo "<input type=\"submit\" class='eltuntet' id=\"datumLeker\" name=\"datumLeker\"  value=\"Nyomtatás\">";
        echo"</form>";
        
    
    if(isset($_POST['datumLeker']))
    {
        echo "<table class='megjelenit'>";
        $datum = $_POST['datum'];
        $tema;
        $sorszam=0;
        $valasztottNyomtatas =  $_POST['nyomtat'];
        
        $sqlCmd = "SELECT * FROM $valasztottNyomtatas where datum = \"$datum\"";

        $result = $conn->query($sqlCmd);
        if ($result->num_rows > 0)
        {
            if($valasztottNyomtatas == "csoportfoglalkozasnaploz")
            {
                echo '<h1 class="fekete">Csoportfoglalkozás</h1>';
            }
            if($valasztottNyomtatas == "szakkorNaploz")
            {
                echo '<h1 class="fekete">Szakkör</h1>';
            }
            while ($row = $result->fetch_assoc())
            {
                $sorszam++;
                $tema = htmlspecialchars($row["tema"]);
                if(htmlspecialchars($row["jelenlet"]) == 1)
                $jelen = "Jelen volt";
                else
                $jelen = "Nem volt jelen";
    
                echo "<tr>";
                echo "<td>".$sorszam ."</td>";
                echo "<td>".htmlspecialchars($row["diakNev"]) ."</td>";
                echo "<td>".$jelen ."</td>";
                echo "</tr>";
                echo "<br>";
            }
                echo "<tr>";
                if($valasztottNyomtatas == "csoportfoglalkozasnaploz")
                {
                    echo "<td colspan='3'>Téma: $tema</td>";
                }
                if($valasztottNyomtatas == "szakkorNaploz")
                {
                    echo "<td colspan='3'>Szakkör: $tema</td>";
                }
                
                echo "</tr>";
                echo "<tr>";
                echo "<td colspan='3'>Dátum: $datum</td>";
                echo "</tr>";
                echo "<tr class='borderMegjelenit'>";
                echo "<td id='alair' colspan='3'>___________________</td>";
                echo "</tr>";
                echo "<tr id='alair'>";
                $userId = $_SESSION['userId'];
                $sqlCmd = "SELECT * FROM users where id = '$userId'";
                $result = $conn->query($sqlCmd);
                if ($result->num_rows > 0)
                while ($row = $result->fetch_assoc())
                echo "<td id='alair' colspan='3'>".htmlspecialchars($row["username"])."</td>";
                echo "</tr>";
                echo "</table>";
                echo "</div>";
                echo "<script>
                        window.print();
                </script>";
                header("refresh: 1");
        }     
        else
        {
            echo "<script> alert('Ezen a napon nem történt naplózás!');</script>";
        }
    }
   
    }
    if(isset($_GET['szakkorNaploz']))
    {
        $aktUserId = $_SESSION['userId'];
        $aktUserSzakkor = $_SESSION['szakkor'];
        $sqlCmd = "SELECT * FROM users where id = '$aktUserId'"; 
        $result = $conn->query($sqlCmd);
        if ($result->num_rows > 0)
        while ($row = $result->fetch_assoc())
        {
            
            if(htmlspecialchars($row["szakkor"]) === '')
            {
                echo "<script>alert('Ön nem rendelkezik szakkörrel!')</script>";
            }else
            {
                
                $datetime = new DateTime( "now", new DateTimeZone( "Europe/Belgrade" ) );
                $jelenlegiIdo = $datetime->format( 'Y-m-d' );
                $sqlCmd = "SELECT * FROM szakkorNaploz where neveloId = '$aktUserId' and datum='$jelenlegiIdo'"; 
                $result = $conn->query($sqlCmd);
                if ($result->num_rows > 0)
                {
                    echo "<script>alert('A mai napon már megtörtént a naplózás!')</script>";
                    break;
                }
                else
                {
                    echo "<div class='naplozDiv'>";
                    echo "<h2>Csoportfoglalkozás naplózása</h2>";
                    echo "<form METHOD='POST'>";
                    $sqlCmd = "SELECT * from diak where szakkor = '$aktUserSzakkor'";
                    $result = $conn->query($sqlCmd);
                    $id=array();
                    if ($result->num_rows > 0)
                    while ($row = $result->fetch_assoc())
                    {
                        
                        array_push($id,htmlspecialchars($row["id"]));
                        //print_r($id);
                        echo "<input type='text' id='A".htmlspecialchars($row["id"])."' name='A".htmlspecialchars($row["id"])."' value='".htmlspecialchars($row["nev"])."' readonly>";
                        echo "<input type='checkbox' id='B".htmlspecialchars($row["id"])."' name='B".htmlspecialchars($row["id"])."'>";
                        echo "<br>";
                    }
                    echo "<label for='tema'>".$_SESSION['szakkor']." szakkör naplózása:</label>";
                    echo "<br><br>";
                   // echo "<input type='text' name='tema' id='tema' placeholder='Téma '>";
                   // echo "<br>";
                    echo "<input type='submit' id='szakkorMent' name='szakkorMent' value='Naplózás'>";
                    echo "</form>";
                    echo "</div>";
                }
            }
        }

        
    }
    if(isset($_POST['szakkorMent']))
    {
        $tema = $_SESSION['szakkor'];
        for($i=0 ; $i < count($id); $i++)
        {
            $pozicioID = "A".$id[$i];
            $pozicioValasz = "B".$id[$i];
            $jelenlegiID = $_POST["$pozicioID"];
            $jelenlegiAdat;
            if (isset($_POST["$pozicioValasz"]))
                $jelenlegiAdat = 1; 
            else
                $jelenlegiAdat = 0;
                $datetime = new DateTime( "now", new DateTimeZone( "Europe/Belgrade" ) );
                $jelenlegiIdo = $datetime->format( 'Y-m-d' );
            $sqlCmd = "INSERT INTO szakkorNaploz(neveloID,diakNev,jelenlet,datum,tema) values('$aktUserId','$jelenlegiID','$jelenlegiAdat','$jelenlegiIdo','$tema')";
            $conn->query($sqlCmd);
        }
        echo "<script>alert('A naplózás sikeres!')</script>";
    }
    if(isset($_GET['csoportFNaploz']))
    {
        $aktUserId = $_SESSION['userId'];

        $sqlCmd = "SELECT * FROM users where id = '$aktUserId'"; 
        $result = $conn->query($sqlCmd);
        if ($result->num_rows > 0)
        while ($row = $result->fetch_assoc())
        {
            if(htmlspecialchars($row["fiokTipus"]) === '0')
            {
                echo "<script>alert('Ön nem rendelkezik csoportvezetői joggal!')</script>";
            }else
            {
                $datetime = new DateTime( "now", new DateTimeZone( "Europe/Belgrade" ) );
                $jelenlegiIdo = $datetime->format( 'Y-m-d' );
                $sqlCmd = "SELECT * FROM csoportfoglalkozasnaploz where neveloId = '$aktUserId' and datum='$jelenlegiIdo'"; 
                $result = $conn->query($sqlCmd);
                if ($result->num_rows > 0)
                {
                    echo "<script>alert('A mai napon már megtörtént a naplózás!')</script>";
                    break;
                }
                else
                {
                    echo "<div class='naplozDiv'>";
                    echo "<h2>Csoportfoglalkozás naplózása</h2>";
                    echo "<form METHOD='POST'>";
                    $sqlCmd = "SELECT * from diak where csoportV = '$aktUserId'";
                    $result = $conn->query($sqlCmd);
                    $id=array();
                    if ($result->num_rows > 0)
                    while ($row = $result->fetch_assoc())
                    {
                        array_push($id,htmlspecialchars($row["id"]));
                        //print_r($id);
                        echo "<input type='text' id='A".htmlspecialchars($row["id"])."' name='A".htmlspecialchars($row["id"])."' value='".htmlspecialchars($row["nev"])."' readonly>";
                        echo "<input type='checkbox' id='B".htmlspecialchars($row["id"])."' name='B".htmlspecialchars($row["id"])."'>";
                        echo "<br>";
                    }
                    echo "<label for='tema'>Kérem írja be a témát:</label>";
                    echo "<br>";
                    echo "<input type='text' name='tema' id='tema' placeholder='Téma' required>";
                    echo "<br>";
                    echo "<input type='submit' id='csoportFMent' name='csoportFMent' value='Naplózás'>";
                    echo "</form>";
                    echo "</div>";
                }
            }
        }

        
    }
    if(isset($_POST['csoportFMent']))
    {
        $tema = $_POST['tema'];
        for($i=0 ; $i < count($id); $i++)
        {
            $pozicioID = "A".$id[$i];
            $pozicioValasz = "B".$id[$i];
            $jelenlegiID = $_POST["$pozicioID"];
            $jelenlegiAdat;
            if (isset($_POST["$pozicioValasz"]))
                $jelenlegiAdat = 1; 
            else
                $jelenlegiAdat = 0;
                $datetime = new DateTime( "now", new DateTimeZone( "Europe/Belgrade" ) );
                $jelenlegiIdo = $datetime->format( 'Y-m-d' );
            $sqlCmd = "INSERT INTO csoportfoglalkozasnaploz(neveloId,diakNev,jelenlet,datum,tema) values('$aktUserId','$jelenlegiID','$jelenlegiAdat','$jelenlegiIdo','$tema')";
            $conn->query($sqlCmd);
        }
        echo "<script>alert('A naplózás sikeres!')</script>";
    }

    ?>
</body>
</html>