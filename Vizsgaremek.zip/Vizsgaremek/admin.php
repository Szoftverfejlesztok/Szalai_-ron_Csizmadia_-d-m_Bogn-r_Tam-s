<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="admin.css">
    <title>Adminisztráció</title>
</head>
<body>
    <?php   
    $servername = "mysql.omega:3306";
    $db_username = "kollegiumseged";
    $db_password = "KollegiumSeged2025!";
    $dbname = "kollegiumseged";
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    if ($conn->connect_error) {
        die("Kapcsolódási hiba: " . $conn->connect_error);
    }
    ?>
    <?php
    session_start();
    if($_SESSION['accountType'] !== '1')
    {
        header("Location: index.php");
    }
    ?>
    <h1>Adminisztráció</h1>
    <button name="hambimenu" class="hambimenu" onclick="myFunction()"><i class="fa fa-bars"> Menu</i></button>
        <div id="menu">
            <form method = "GET">
                    <hr>
                    <input type="submit" name="diakHozzaad" id = "diakHozzaad" value="Diák hozzáadása">
                    <input type="submit" name="diakModosit" id = "diakModosit" value="Diák módosítása">
                    <input type="submit" name="diakTorles" id = "diakTorles" value="Diák törlése">
                    <input type="submit" name="szobaHozzaad" id = "szobaHozzaad" value="Szoba hozzáadása">
                    <input type="submit" name="szobaTorol" id = "szobaTorol" value="Szoba törlése">
                    
                    <input type="submit" name="userHozzaad" id = "userHozzaad" value="Felhasználó hozzáadása">
                    <input type="submit" name="userModosit" id = "userModosit" value="Felhasználó módosítása">
                    <input type="submit" name="userTorol" id = "userTorol" value="Felhasználó törlése">
                    <br>
                    <input type="submit" name="kijelentkez" id = "kijelentkez" value="Kijelentkezés">
                    <hr>
            </form>
        </div>
        <script>
        function myFunction() {
            var x = document.getElementById("menu");
            if(x.style.display === "block")
            {
                x.style.display = "none";
            }
            else
            {
                x.style.display = "block";
            }
        }
        </script>

        <?php
            if(isset($_GET['kijelentkez']))
            {
                header("Location: logout.php");
            }


            if(isset($_GET['diakTorles']))
            {
                echo "<div class='hozzaadDiv'>";
                echo "<h2>Diák törlése</h2>";
                echo "<form method='POST'>"; 
                echo "<br>";
                echo "<label for='dNev'>Kérem válassza ki a törölni kívánt diák nevét:</label>";
                echo "<br>";
                echo "<select name='dNev' id='dNev'>";
                    $sqlCmd = "SELECT * FROM diak";
                    $result = $conn->query($sqlCmd);
                    if ($result->num_rows > 0)
                    while ($row = $result->fetch_assoc())
                    {
                        echo "<option value='".htmlspecialchars($row["id"])."'>".htmlspecialchars($row["nev"])."</option>";
                    }
                echo "</select>";
                echo "<br>";
                echo '<input type="submit" id="diakTorol" name="diakTorol" value="Törlés">';
                echo "</form>";
                echo "</div>";
            }
            if(isset($_POST['diakTorol']))
            {
                $diakId = $_POST['dNev'];
                $sqlCmd = "DELETE from diak where id = '$diakId'";
                $conn->query($sqlCmd);
                echo "<script>alert('A diák törlése megtörnét!')</script>"; 
                header("refresh: 1");
            }
            if(isset($_GET['szobaTorol']))
            {
                echo "<div class='hozzaadDiv'>";
                echo "<h2>Szoba törlése</h2>";
                echo "<br>";
                echo "<form method='POST'>";
                echo "<label for='torolSzoba'>Kérem válassza ki a szobát </label>";
                echo "<br>";
                echo "<select name='torolSzoba' id='torolSzoba'>";
                    $sqlCmd = "SELECT * FROM szobak";
                    $result = $conn->query($sqlCmd);
                    if ($result->num_rows > 0)
                    while ($row = $result->fetch_assoc())
                    {
                        echo "<option value='".htmlspecialchars($row["id"])."'>".htmlspecialchars($row["szobaSz"])."</option>";
                    }
                echo "</select>";
                echo "<br>";
                echo "<input type='submit' id='szobaVeglegTorol' name='szobaVeglegTorol' value='Törlés'>";
                echo "</form>";
                echo "</div>";
            }

            if(isset($_POST['szobaVeglegTorol']))
            {
                $szobaSzId = $_POST['torolSzoba'];
                $sqlCmdSzobahozRendeltekSzama = "SELECT * FROM diak where szobaSz = '$szobaSzId'";
                $resultSzobakhoz = $conn->query($sqlCmdSzobahozRendeltekSzama);
                if($resultSzobakhoz->num_rows > 0){
                    echo "<script>alert('A szoba nem üres, így nem töröltük!')</script>;";
                }else{
                    $sqlCmd = "DELETE from szobak where id = '$szobaSzId'";
                $conn->query($sqlCmd);
                echo "<script>alert('A szoba törlése megtörnét!')</script>"; 
                header("refresh: 1");

                }
                

                
            }

            if(isset($_GET['diakModosit']))
            {
                echo "<div class='hozzaadDiv'>";
                echo "<h2>Diák módosítása</h2>";
                echo "<br>";
                echo "<form method='POST'>";
                echo "<label for='modositDiak'>Kérem válassza ki a diákot </label>";
                echo "<br>";
                echo "<select name='modositDiak' id='modositDiak'>";
                    $sqlCmd = "SELECT * FROM diak";
                    $result = $conn->query($sqlCmd);
                    if ($result->num_rows > 0)
                    while ($row = $result->fetch_assoc())
                    {
                        echo "<option value='".htmlspecialchars($row["id"])."'>".htmlspecialchars($row["nev"])."</option>";
                    }
                echo "</select>";
                echo "<br>";
                echo "<input type='submit' id='diakLekerdez' name='diakLekerdez' value='Lekérdezés'>";
                echo "</form>";
                echo "</div>";
            }

            if(isset($_POST['diakLekerdez']))
            {
                $lekerdezUserId = $_POST['modositDiak'];
                
                echo "<div class='hozzaadDiv'>";
                echo "<h2>Diák módosítása</h2>";
                echo "<br>";
                echo "<form method='POST'>";
                echo "<input type='text' style='display: none;' name='userId' id='userId' value='$lekerdezUserId' readonly>";
                echo "<label for='diakNev'>Diák neve</label>";
                echo "<br>";
                
                $diakSzakkor;
                $diakNevId = $_POST['modositDiak'];
                $sqlCmd = "SELECT * FROM diak where id= '$diakNevId'";
                    $result = $conn->query($sqlCmd);
                    if ($result->num_rows > 0)
                    while ($row = $result->fetch_assoc())
                    {
                        echo "<input type='text' name='diakNev' id='".htmlspecialchars($row["id"])."' value='".htmlspecialchars($row["nev"])."' readonly>";
                        $szobaSzAkt = htmlspecialchars($row["szobaSz"]);
                        $csoportVAkt = htmlspecialchars($row["csoportV"]);
                    }
                    echo "<br>";
                    echo "<label for='modositDiakSzoba'>Szoba száma</label>";
                    echo "<select name='modositDiakSzoba' id='modositDiakSzoba'>";
                    $sqlCmd = "SELECT * FROM szobak";
                    $result = $conn->query($sqlCmd);
                    if ($result->num_rows > 0)
                    while ($row = $result->fetch_assoc())
                    {
                        if($szobaSzAkt === htmlspecialchars($row["id"]))
                        {
                            echo "<option value='".htmlspecialchars($row["id"])."' selected>".htmlspecialchars($row["szobaSz"])."</option>";
                        }else
                        {
                            echo "<option value='".htmlspecialchars($row["id"])."'>".htmlspecialchars($row["szobaSz"])."</option>";
                        }
                        
                    }
                echo "</select>";
                echo "<br>";
                echo "<label for='szakkorModosit'>Kérem válassza ki a szakkört </label>";
                echo "<br>";
                echo "<select name='szakkorModosit' id='szakkorModosit'>";
                    $sqlCmd = "SELECT * FROM diak where id = '$diakNevId'";
                    $result = $conn->query($sqlCmd);
                    if ($result->num_rows > 0)
                    while ($row = $result->fetch_assoc())
                    {
                        echo "<option value='".htmlspecialchars($row["szakkor"])."' selected>".htmlspecialchars($row["szakkor"])."</option>";
                        $diakSzakkor = htmlspecialchars($row["szakkor"]);
                    }


                    $sqlCmd = "SELECT * FROM users";
                    $result = $conn->query($sqlCmd);
                    if ($result->num_rows > 0)
                    while ($row = $result->fetch_assoc())
                    {
                        if(htmlspecialchars($row["szakkor"]) != "")
                        {
                            if(htmlspecialchars($row["szakkor"]) != $diakSzakkor)
                            echo "<option value='".htmlspecialchars($row["szakkor"])."'>".htmlspecialchars($row["szakkor"])."</option>";
                        }
                    }
                echo "</select>";
                echo "<br>";
                echo "<label for='modositDiakCsoportV'>Csoportvezető</label>";
                echo "<select name='modositDiakCsoportV' id='modositDiakCsoportV'>";
                $sqlCmd = "SELECT * FROM users where fiokTipus = 2";
                $result = $conn->query($sqlCmd);
                if ($result->num_rows > 0)
                while ($row = $result->fetch_assoc())
                {
                    if($csoportVAkt === htmlspecialchars($row["id"]))
                    {
                        echo "<option value='".htmlspecialchars($row["id"])."' selected>".htmlspecialchars($row["username"])."</option>";
                    }else
                    {
                        echo "<option value='".htmlspecialchars($row["id"])."'>".htmlspecialchars($row["username"])."</option>";
                    }
                    
                }
            echo "</select>";
            echo"<br>";
                echo "<input type='submit' id='diakAthelyez' name='diakAthelyez' value='Áthelyezés'>";
                echo "</form>";
                echo "</div>";
            }

            if(isset($_POST['diakAthelyez']))
            {
                $szakkorModositas = $_POST['szakkorModosit'];
                $ujCsoportV = $_POST['modositDiakCsoportV'];
                $ujSzobaSz = $_POST['modositDiakSzoba'];
                $userId = $_POST['userId'];

                $sqlCmdSzobahozRendeltekSzama = "SELECT * FROM diak where szobaSz = '$ujSzobaSz'";
                $resultSzobakhoz = $conn->query($sqlCmdSzobahozRendeltekSzama);
                $sqlCmdSzobaKapacitas = "SELECT kapacitas FROM szobak where id = '$ujSzobaSz'";
                $resultKapacitas = $conn->query($sqlCmdSzobaKapacitas);
                $szobaKapacitas = $resultKapacitas->fetch_assoc();
                if($resultSzobakhoz->num_rows >=  htmlspecialchars($szobaKapacitas["kapacitas"]))
                {
                    echo "<script>alert('A szoba tele van, így nem tudtuk áthelyezni a diákot!')</script>"; 
                }else
                {
                    $sqlCmd = "UPDATE diak set szakkor = '$szakkorModositas',szobaSz = '$ujSzobaSz',csoportV = '$ujCsoportV' where id='$userId'";
                    $conn->query($sqlCmd);
                    echo "<script>alert('A diák adatai módisítása megtörnét!')</script>"; 
                }
            }

            if(isset($_GET['userTorol']))
            {
                echo "<div class='hozzaadDiv'>";
                echo "<h2>Felhasználó törlése</h2>";
                echo "<br>";
                echo "<form method='POST'>";
                echo "<label for='modositUser'>Kérem válassza ki a felhasználót </label>";
                echo "<br>";
                echo "<select name='torolUser' id='torolUser'>";
                    $sqlCmd = "SELECT * FROM users";
                    $result = $conn->query($sqlCmd);
                    if ($result->num_rows > 0)
                    while ($row = $result->fetch_assoc())
                    {
                        echo "<option value='".htmlspecialchars($row["id"])."'>".htmlspecialchars($row["username"])."</option>";
                    }
                echo "</select>";
                echo"<br>";
                echo "<input type='submit' id='userVeglegTorol' name='userVeglegTorol' value='Törlés'>";
                echo "</form>";
                echo "</div>";
            }

            if(isset($_POST['userVeglegTorol']))
            {
                $userTorolId = $_POST['torolUser'];
                $sqlCmd = "DELETE FROM users where id = '$userTorolId'";
                $conn->query($sqlCmd);
                echo "<script>alert('A felhasználó sikeresen törölve!')</script>"; 
                header("refresh: 1");
            }

            if(isset($_GET['userModosit']))
            {
                echo "<div class='hozzaadDiv'>";
                echo "<h2>Felhasználó módosítása</h2>";
                echo "<br>";
                echo "<form method='POST'>";
                echo "<label for='modositUser'>Kérem válassza ki a felhasználót </label>";
                echo "<br>";
                echo "<select name='modositUser' id='modositUser'>";
                    $sqlCmd = "SELECT * FROM users";
                    $result = $conn->query($sqlCmd);
                    if ($result->num_rows > 0)
                    while ($row = $result->fetch_assoc())
                    {
                        echo "<option value='".htmlspecialchars($row["id"])."'>".htmlspecialchars($row["username"])."</option>";
                    }
                echo "</select>";
                echo"<br>";
                echo "<input type='submit' id='userLekerdez' name='userLekerdez' value='Lekérdezés'>";
                echo "</form>";
                echo "</div>";
            }

            if(isset($_POST['userLekerdez']))
            {
                $lekerdezUserId = $_POST['modositUser'];
                $sqlCmd = "SELECT * FROM users WHERE id = '$lekerdezUserId'";
                $result = $conn->query($sqlCmd);
                    if ($result->num_rows > 0)
                    while ($row = $result->fetch_assoc())
                    {
                        $lekerdezUser = htmlspecialchars($row["username"]);
                        $lekerdezfiokTipus = htmlspecialchars($row["fiokTipus"]);
                        $lekerdezJelszo = htmlspecialchars($row["password"]);
                        $szakkor = htmlspecialchars($row["szakkor"]);
                    }
                echo "<div class='hozzaadDiv'>";
                echo "<h2>Felhasználó módosítása</h2>";
                echo "<br>";
                echo "<form method='POST'>";
                echo "<input type='text' style='display: none;' name='userId' id='userId' value='$lekerdezUserId' readonly>";
                echo "<label for='Nusername'>Felhasználónév </label>";
                echo "<br>";
                echo "<input type='text' name='modositUser' id='modositUser' value='$lekerdezUser' readonly>";
                echo "<br>";
                echo "<label for='Npassword'>Kérem a jelszavat </label>";
                echo "<br>";
                echo "<input type='password' name='ujJelszoModosit' id='ujJelszoModosit' value='$lekerdezJelszo' required>";
                echo "<br>";
                echo "<label for='Npassword'>Kérem a szakkör nevét </label>";
                echo "<br>";
                echo "<input type='text' name='szakkorModosit' id='szakkorModosit' value='$szakkor' >";
                echo "<br>";
                echo "<label for='jelszo'>Kérem a válassza ki a fiók típusát </label>";
                echo "<br>";
                echo "<select name='fiokTipus' id='fiokTipus'>";
                    if($lekerdezfiokTipus === '0')
                    {
                        echo "<option value='0' selected>Felhasználó</option>";
                        echo "<option value='1'>Admin</option>";
                        echo "<option value='2'>Csoportvezető</option>";
                    }else if($lekerdezfiokTipus === '1')
                    {
                        echo "<option value='0' >Felhasználó</option>";
                        echo "<option value='1' selected>Admin</option>";
                        echo "<option value='2'>Csoportvezető</option>";
                    }else if($lekerdezfiokTipus === '2')
                    {
                        echo "<option value='0' >Felhasználó</option>";
                        echo "<option value='1' >Admin</option>";
                        echo "<option value='2' selected>Csoportvezető</option>";
                    }
                echo "</select>";
                echo "<br>";
                echo "<input type='submit' id='userModositLekerdez' name='userModositLekerdez' value='Módosítás'>";
                echo "</form>";
                echo "</div>";
            }

            if(isset($_POST['userModositLekerdez']))
            {
                $lekerdezUserId = $_POST['userId'];
                $fiokTipusLekerdezes = $_POST['fiokTipus'];
                $lekerdezJelszo = $_POST['ujJelszoModosit'];
                $szakkorModosit = $_POST['szakkorModosit'];
                $sqlCmd = "UPDATE users set `password` = '$lekerdezJelszo',szakkor = '$szakkorModosit', fiokTipus = '$fiokTipusLekerdezes' where id='$lekerdezUserId'";
                $conn->query($sqlCmd);
                echo "<script>alert('A felhasználó adatai sikeresen módosítva!')</script>"; 
            }

            if(isset($_GET['userHozzaad']))
            {
                echo "<div class='hozzaadDiv'>";
                echo "<h2>Felhasználó hozzáadása</h2>";
                echo "<br>";
                echo "<form method='POST'>";
                echo "<label for='Nusername'>Kérem a felhasználónevet </label>";
                echo "<br>";
                echo "<input type='text' name='Nusername' id='Nusername' placeholder='Felhasználónév' required>";
                echo "<br>";
                echo "<label for='Npassword'>Kérem a jelszavat </label>";
                echo "<br>";
                echo "<input type='password' name='Npassword' id='Npassword' placeholder='Jelszó' required>";
                echo "<br>";
                echo "<label for='jelszo'>Kérem a válassza ki a fiók típusát </label>";
                echo "<br>";
                echo "<select name='fiokTipus' id='fiokTipus'>";
                    echo "<option value='0' selected>Felhasználó</option>";
                    echo "<option value='1'>Admin</option>";
                    echo "<option value='2'>Csoportvezető</option>";
                echo "</select>";
                echo "<br>";
                echo "<label for='szakkor'>Kérem írja be a szakkör nevét: </label>";
                echo "<br>";
                echo "<input type='text' name='szakkor' id='szakkor' placeholder='Szakkör'>";
                echo "<br>";
                echo "<input type='submit' id='userHozzaad' name='userHozzaad' value='Hozzáadás'>";
                echo "</form>";
                echo "</div>";
            }

            if(isset($_POST['userHozzaad']))
            {
                $Nusername = $_POST['Nusername'];
                $Npassword = $_POST['Npassword'];
                $fiokTipus = $_POST['fiokTipus'];
                $szakkor = $_POST['szakkor'];

                $sqlCmd = "SELECT * FROM users WHERE username = '$Nusername'";
                $result = $conn->query($sqlCmd);
                if ($result->num_rows > 0)
                {
                    echo "<script>alert('A megadott felhasználó már szerepel az adatbázisban!')</script>";
                }else
                {
                    $sqlCmd = "INSERT INTO users(username,password,fiokTipus,szakkor) VALUES ('$Nusername','$Npassword','$fiokTipus','$szakkor')";
                    $result = $conn->query($sqlCmd);
                    echo "<script>alert('A felhasználó adatai feltöltése sikeres!')</script>"; 
                }
            }



            if(isset($_GET['diakHozzaad']))
            {
                echo "<div class='hozzaadDiv'>";
                echo "<h2>Diák hozzáadása</h2>";
                echo "<br>";
                echo "<form method='POST'>";
                echo "<label for='nev'>Kérem a diák nevét </label>";
                echo "<br>";
                echo "<input type='text' name='nev' id='nev' placeholder='Diák neve' required>";
                echo "<br>";
                echo "<label for='nev'>Kérem válassza ki a szoba számát </label>";
                echo "<br>";
                echo "<select name='szobaSzH' id='szobaSzH'>"; 
                $sqlCmd = "SELECT * FROM szobak";
                $result = $conn->query($sqlCmd);
                if ($result->num_rows > 0)
                {
                    while ($row = $result->fetch_assoc())
                    {
                        echo "<option value='".htmlspecialchars($row["id"])."'>".htmlspecialchars($row["szobaSz"])."</option>";
                    }
                }else
                {
                    echo "<script>alert('Nem található szoba az adatbázisban!')</script>";
                }
                echo "</select>";
                echo "<br>";
                echo "<label for='nev'>Kérem válassza ki a csoportvezetőt </label>";
                echo "<br>";
                echo "<select name='csoportV' id='csoportV'>"; 
                $sqlCmd = "SELECT * FROM users where fiokTipus = '2'";
                $result = $conn->query($sqlCmd);
                if ($result->num_rows > 0)
                {
                    while ($row = $result->fetch_assoc())
                    {
                        echo "<option value='".htmlspecialchars($row["id"])."'>".htmlspecialchars($row["username"])."</option>";
                    }
                }else
                {
                    echo "<script>alert('Nem található csoportvezető az adatbázisban!')</script>";
                }
                echo "</select>";
                echo "<br>";
                echo "<label for='szakkorHozzaad'>Kérem válassza ki a szakkört </label>";
                echo "<br>";
                echo "<select name='szakkorHozzaad' id='szakkorHozzaad'>"; 
                $sqlCmd = "SELECT * FROM users";
                $result = $conn->query($sqlCmd);
                if ($result->num_rows > 0)
                {
                    while ($row = $result->fetch_assoc())
                    {
                        echo "<option value='".htmlspecialchars($row["szakkor"])."'>".htmlspecialchars($row["szakkor"])."</option>";
                    }
                }else
                {
                    echo "<script>alert('Nem található szakkör az adatbázisban!')</script>";
                }
                echo "</select>";
                echo "<br>";
                echo "<input type='submit' id='diakHozzaadFeltolt' name='diakHozzaadFeltolt' value='Hozzáadás'>";
                echo "</form>";
                echo "</div>";
            }

            if(isset($_POST['diakHozzaadFeltolt']))
            {
                $nev = $_POST['nev'];
                $szobaSz = $_POST['szobaSzH'];
                $csoportvezeto = $_POST['csoportV'];
                $szakkor = $_POST['szakkorHozzaad'];
                $sqlCmd = "SELECT * FROM diak where nev = '$nev'";
                $result = $conn->query($sqlCmd);
                
                    $sqlCmdSzobahozRendeltekSzama = "SELECT * FROM diak where szobaSz = '$szobaSz'";
                    $resultSzobakhoz = $conn->query($sqlCmdSzobahozRendeltekSzama);
                    $sqlCmdSzobaKapacitas = "SELECT kapacitas FROM szobak where id = '$szobaSz'";
                    $resultKapacitas = $conn->query($sqlCmdSzobaKapacitas);
                    $szobaKapacitas = $resultKapacitas->fetch_assoc();
                    if($resultSzobakhoz->num_rows >=  htmlspecialchars($szobaKapacitas["kapacitas"]))
                    {
                        echo "<script>alert('A szoba tele van!')</script>"; 
                    }else
                    {
                        $sqlCmd = "INSERT INTO diak(nev,szobaSz,csoportV,szakkor) VALUES ('$nev','$szobaSz','$csoportvezeto','$szakkor')";
                        $result = $conn->query($sqlCmd);
                        echo "<script>alert('A diák adatai feltöltése sikeres!')</script>"; 
                    }
                
            }



            if(isset($_GET['szobaHozzaad']))
            {
                echo "<div class='hozzaadDiv'>";
                echo "<h2>Szoba hozzáadása</h2>";
                echo "<br>";
                echo "<form method='POST'>";
                echo "<label for='szobaSz'>Kérem a szoba számát </label>";
                echo "<br>";
                echo "<input type='text' name='szobaSz' id='szobaSz' placeholder='Szoba száma' required>";
                echo "<br>";
                echo "<label for='szobaK'>Kérem a szobakapacitását </label>";
                echo "<br>";
                echo "<input type='number' name='szobaK' id='szobaK' placeholder='Szobakapacitása' required>";
                echo "<br>";
                echo "<input type='submit' id='szobaSzamHozzaad' name='szobaSzamHozzaad' value='Hozzáadás'>";
                echo "</form>";
                echo "</div>";
            }

            if(isset($_POST['szobaSzamHozzaad']))
            {
                $szobaSz = $_POST['szobaSz'];
                $kapacitas = $_POST['szobaK'];
                $sqlCmd = "SELECT * FROM szobak where szobaSz = '$szobaSz'";
                $result = $conn->query($sqlCmd);
                if ($result->num_rows > 0)
                {
                    echo "<script>alert('A megadott szoba már szerepel az adatbázisban!')</script>";
                }
                else if($kapacitas < 1)
                {
                    echo "<script>alert('Kérem nullától nagyobb számot adjon meg!')</script>";
                }
                else
                {
                    $sqlCmd = "INSERT INTO szobak(id,szobaSz,kapacitas) VALUES ('','$szobaSz','$kapacitas')";
                    $conn->query($sqlCmd);
                    echo "<script>alert('A szoba száma és kapacitás feltöltése sikeres!')</script>"; 
                }
            }
        ?>
    
</body>
</html>